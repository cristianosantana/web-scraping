CREATE TABLE `LIrdgrzapp`.`jobs` ( 
`id` INT NOT NULL , 
`company` VARCHAR(60) NOT NULL , 
`district` VARCHAR(60) NOT NULL , 
`locality` VARCHAR(60) NOT NULL , 
`salary` VARCHAR(40) NOT NULL , 
`title` VARCHAR(300) NOT NULL , 
`content` LONGTEXT NOT NULL , 
`created_at` DATE NOT NULL , 
`updated_at` DATE NOT NULL , 
`deleted_at` DATE NOT NULL , 
PRIMARY KEY (`id`)
) ENGINE = InnoDB;